<template>
    <div class="container">
        <h2>Home</h2>
    </div>
</template>

<script>
    export default {
        name:"Home",
    }
</script>
